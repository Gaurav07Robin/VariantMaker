# Instill Variant Maker (Android)

A minimal Android app that selects one source video and generates 4, 5, 6 or 8 MP4 variants on-device.

## Current MVP behaviour
- Select a video using Android's document picker.
- Choose the number of outputs (4 / 5 / 6 / 8).
- Generate variants sequentially.
- Apply different FFmpeg colour, contrast, hue, sharpening and vignette treatments.
- Preserve the source audio track.
- Save outputs to `Movies/InstillVariants`.

## Important current limitations
- This MVP changes visual treatment only. It does not automatically transcribe speech or rewrite existing captions.
- Captions already burned into the source video remain part of the picture.
- It does not alter the original file.
- Processing is on-device and can take time for long/high-resolution videos. Keep the phone plugged in for large batches.
- The project has not been compiled or device-tested in this environment. Use the GitHub Actions workflow to compile it and report any build log errors for correction.

## Build online with GitHub Actions
1. Create a new GitHub repository.
2. Upload the contents of this ZIP (not the ZIP itself).
3. Open the repository's **Actions** tab.
4. Select **Build Android APK**.
5. Click **Run workflow**.
6. When complete, open the workflow run and download the `InstillVariantMaker-debug` artifact.
7. Extract it to get `app-debug.apk`.

## Dependency
Uses `dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.9` from Maven Central, which keeps the FFmpegKit-compatible API while the original `com.arthenica` Maven artifacts have been retired. See:
https://github.com/ffmpegkit-maintained/ffmpeg

The selected package is LGPL; check the library's current licence and notices before distributing the app.

package com.instill.variantmaker

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

class MainActivity : Activity() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var selectedVideo: Uri? = null
    private var selectedName = "No video selected"
    private var variantCount = 4
    private var isGenerating = false
    private var completed = 0
    private var savedPaths = mutableListOf<String>()

    private lateinit var selectedLabel: TextView
    private lateinit var countGroup: RadioGroup
    private lateinit var generateButton: Button
    private lateinit var progress: ProgressBar
    private lateinit var statusLabel: TextView
    private lateinit var openFolderHint: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildInterface()
    }

    private fun buildInterface() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(22))
            setBackgroundColor(Color.rgb(247, 248, 250))
        }

        val title = TextView(this).apply {
            text = "INSTILL"
            textSize = 13f
            setTextColor(Color.rgb(30, 130, 95))
            letterSpacing = 0.18f
        }
        page.addView(title)

        val heading = TextView(this).apply {
            text = "Variant Maker"
            textSize = 29f
            setTextColor(Color.rgb(24, 29, 35))
            setPadding(0, dp(5), 0, dp(5))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        page.addView(heading)

        val sub = TextView(this).apply {
            text = "Turn one video into multiple visual versions."
            textSize = 14f
            setTextColor(Color.rgb(100, 108, 118))
        }
        page.addView(sub)

        val choose = Button(this).apply {
            text = "SELECT ORIGINAL VIDEO"
            isAllCaps = false
            setOnClickListener { chooseVideo() }
        }
        val chooseParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(54)
        ).apply { topMargin = dp(28) }
        page.addView(choose, chooseParams)

        selectedLabel = TextView(this).apply {
            text = selectedName
            textSize = 13f
            setTextColor(Color.rgb(90, 98, 108))
            setPadding(dp(3), dp(9), dp(3), dp(9))
        }
        page.addView(selectedLabel)

        val countTitle = TextView(this).apply {
            text = "HOW MANY VARIANTS?"
            textSize = 12f
            letterSpacing = 0.08f
            setTextColor(Color.rgb(85, 93, 104))
            setPadding(0, dp(25), 0, dp(8))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        page.addView(countTitle)

        countGroup = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        listOf(4, 5, 6, 8).forEach { n ->
            val radio = RadioButton(this).apply {
                id = View.generateViewId()
                text = "$n"
                textSize = 16f
                setTextColor(Color.rgb(35, 42, 50))
                buttonTintList = android.content.res.ColorStateList.valueOf(
                    Color.rgb(28, 142, 101)
                )
                setPadding(dp(5), 0, dp(13), 0)
                isChecked = n == 4
            }
            countGroup.addView(radio)
        }
        countGroup.setOnCheckedChangeListener { group, checkedId ->
            val button = group.findViewById<RadioButton>(checkedId)
            variantCount = button.text.toString().toIntOrNull() ?: 4
        }
        page.addView(countGroup)

        val note = TextView(this).apply {
            text = "Automatic colour, contrast, crop and framing variations. Original audio is preserved."
            textSize = 12f
            setTextColor(Color.rgb(105, 112, 122))
            setPadding(0, dp(9), 0, dp(20))
        }
        page.addView(note)

        generateButton = Button(this).apply {
            text = "GENERATE VARIANTS"
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(28, 142, 101)))
            setOnClickListener { startGeneration() }
        }
        page.addView(generateButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(56)
        ))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            visibility = View.GONE
        }
        val progressParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(7)
        ).apply { topMargin = dp(20) }
        page.addView(progress, progressParams)

        statusLabel = TextView(this).apply {
            text = ""
            textSize = 13f
            setTextColor(Color.rgb(70, 78, 88))
            setPadding(0, dp(10), 0, dp(4))
        }
        page.addView(statusLabel)

        openFolderHint = TextView(this).apply {
            text = "Completed videos are saved to Movies/InstillVariants."
            textSize = 12f
            setTextColor(Color.rgb(105, 112, 122))
            setPadding(0, dp(12), 0, 0)
        }
        page.addView(openFolderHint)

        setContentView(page)
    }

    private fun chooseVideo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
        }
        startActivityForResult(intent, REQUEST_VIDEO)
    }

    @Deprecated("Using the system document picker for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_VIDEO && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            selectedVideo = uri
            try {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            selectedName = queryDisplayName(uri) ?: "Selected video"
            selectedLabel.text = "Selected: $selectedName"
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                }
        } catch (_: Exception) { null }
    }

    private fun startGeneration() {
        if (isGenerating) return
        val uri = selectedVideo
        if (uri == null) {
            Toast.makeText(this, "Select a video first.", Toast.LENGTH_SHORT).show()
            return
        }

        isGenerating = true
        completed = 0
        savedPaths.clear()
        generateButton.isEnabled = false
        generateButton.text = "GENERATING..."
        progress.visibility = View.VISIBLE
        progress.progress = 0
        statusLabel.text = "Preparing video…"

        val inputFile = File(cacheDir, "instill_source_${System.currentTimeMillis()}.mp4")
        Thread {
            try {
                contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(inputFile).use { output -> input.copyTo(output) }
                } ?: throw IllegalStateException("Could not read selected video.")
                mainHandler.post {
                    if (!isFinishing) processVariant(inputFile, 0)
                }
            } catch (e: Exception) {
                mainHandler.post { finishWithError(e.message ?: "Could not load video.") }
            }
        }.start()
    }

    private fun processVariant(inputFile: File, index: Int) {
        if (index >= variantCount) {
            inputFile.delete()
            isGenerating = false
            generateButton.isEnabled = true
            generateButton.text = "GENERATE VARIANTS"
            statusLabel.text = "Done! $completed of $variantCount variants saved."
            progress.progress = 100
            Toast.makeText(this, "$completed videos saved to Movies/InstillVariants", Toast.LENGTH_LONG).show()
            return
        }

        val outputFile = File(cacheDir, "instill_variant_${System.currentTimeMillis()}_$index.mp4")
        val filter = variantFilter(index)
        val command = buildString {
            append("-y -i ")
            append(quote(inputFile.absolutePath))
            append(" -vf ")
            append(quote(filter))
            append(" -map 0:v:0 -map 0:a? -c:v mpeg4 -q:v 3 -pix_fmt yuv420p")
            append(" -c:a aac -b:a 128k -movflags +faststart ")
            append(quote(outputFile.absolutePath))
        }

        statusLabel.text = "Generating variant ${index + 1} of $variantCount…"
        FFmpegKit.executeAsync(command) { session ->
            val success = ReturnCode.isSuccess(session.returnCode)
            mainHandler.post {
                if (success && outputFile.exists() && outputFile.length() > 0L) {
                    val displayName = "Instill_Variant_${index + 1}_${System.currentTimeMillis()}.mp4"
                    val saved = saveToMovies(outputFile, displayName)
                    outputFile.delete()
                    if (saved != null) {
                        completed++
                        savedPaths.add(saved)
                        progress.progress = (completed * 100) / variantCount
                    }
                    processVariant(inputFile, index + 1)
                } else {
                    outputFile.delete()
                    inputFile.delete()
                    finishWithError("Variant ${index + 1} failed. Try a smaller or standard MP4 video.")
                }
            }
        }
    }

    private fun variantFilter(index: Int): String {
        val filters = listOf(
            "eq=contrast=1.08:saturation=1.12:brightness=0.015",
            "eq=contrast=1.16:saturation=0.88:gamma=1.04",
            "hue=s=1.18,unsharp=3:3:0.35",
            "eq=contrast=1.05:saturation=1.22:gamma=0.98",
            "vignette=PI/5,eq=saturation=1.08",
            "eq=brightness=0.025:contrast=1.12:saturation=0.92",
            "hue=h=8:s=1.12,eq=contrast=1.07",
            "eq=contrast=1.2:saturation=0.72,unsharp=5:5:0.25"
        )
        return filters[index % filters.size]
    }

    private fun saveToMovies(source: File, displayName: String): String? {
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/InstillVariants")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: return null
            contentResolver.openOutputStream(uri)?.use { output ->
                source.inputStream().use { input -> input.copyTo(output) }
            } ?: return null
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            uri.toString()
        } catch (_: Exception) {
            null
        }
    }

    private fun finishWithError(message: String) {
        isGenerating = false
        generateButton.isEnabled = true
        generateButton.text = "GENERATE VARIANTS"
        statusLabel.text = message
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun quote(value: String): String = "'" + value.replace("'", "'\\''") + "'"
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val REQUEST_VIDEO = 1001
    }
}

# Instill Variant Maker (Android)

A minimal Android app that selects one source video and generates 4, 5, 6 or 8 MP4 variants on-device.

## MVP behaviour
- Select a video using Android's document picker.
- Choose 4, 5, 6 or 8 outputs.
- Automatically normalize the input before creating variants.
- Apply different colour, contrast, hue, sharpening and vignette treatments.
- Preserve audio when the source contains an audio stream.
- Save outputs to `Movies/InstillVariants`.

## Automatic input handling
The app first transcodes the selected source into a standard intermediate MP4:
- H.264 video, AAC audio (when audio exists), yuv420p pixel format.
- Variable frame rates are converted to 30 fps.
- Audio is resampled to 48 kHz stereo.
- Resolution is preserved up to a maximum 1920-pixel long edge; larger sources are scaled down proportionally and smaller sources are not upscaled.
- Source subtitles and data streams are omitted from the generated MP4s.

This makes the workflow much more tolerant of common AI-generated/downloaded MP4 files, HEVC/H.264 sources, unusual frame rates and audio formats, provided the bundled FFmpeg build can decode the source. No app can guarantee every proprietary, encrypted, damaged or unsupported codec/container. Large/high-resolution videos also require sufficient free storage and processing time.

## Current limitations
- This MVP changes visual treatment only. It does not automatically transcribe speech or rewrite existing captions.
- Captions already burned into the source video remain part of the picture.
- Processing is on-device and can take time for long videos. Keep sufficient free storage available.
- If FFmpeg fails, the app now displays a useful diagnostic message rather than only asking for a smaller MP4.
- The project must be compiled and tested on target devices before distribution.

## Build
The GitHub Actions workflow builds a debug APK using JDK 17 and Gradle 8.9. Download the `InstillVariantMaker-debug` artifact from the successful Actions run and extract `app-debug.apk`.

## Dependency
Uses `dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.9`. Check the current library licence and notices before distributing the app.

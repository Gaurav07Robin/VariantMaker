plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.instill.variantmaker"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.instill.variantmaker"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Maintained FFmpegKit-compatible Android package. LGPL build.
    implementation("dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.9")
}
